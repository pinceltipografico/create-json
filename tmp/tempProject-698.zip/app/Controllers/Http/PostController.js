'use strict'

class PostController {
}

module.exports = PostController
